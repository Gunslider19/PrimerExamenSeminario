﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;

public class GameController : MonoBehaviour {
    
    public InputField  nota1t;
    public InputField nota2t;
    public InputField nota3t;
    public Text PromedioK;
    public int nota1;
    public int nota2;
    public int nota3;
    public float promedio;
    public string nn1, nn2, nn3;
    public string nume1,nume2,nume3;

    // Use this for initialization
    void Start () {
        
		
	}
   

    // Update is called once per frame
    void Update () {
       
	}
   
    public void capturarn1(string num1)
    {
        nume1 = num1;
    }
    public void capturarn2(string num2)
    {
        nume2 = num2;
    }
    public void capturarn3(string num3)
    {
        nume3 = num3;
    }




    public void calcularpromedio()
    {

        /*nn1 = nota1t.text;
        nn2 = nota2t.text;
        nn3 = nota3t.text;
        nota1 = int.Parse(nn1);
        nota2 = int.Parse(nn2);
        nota3 = int.Parse(nn3);*/

        // promedio =(nota1+nota2+nota3)/ 3;
        nn1 = nume1;
        nn2 = nume2;
        nn3 = nume3;
        nota1 = int.Parse(nn1);
        nota2 = int.Parse(nn2);
        nota3 = int.Parse(nn3);
        promedio = (nota1+nota2+nota3)/3;
        PromedioK.text = promedio.ToString();

    }
   /* void hit(string WhatWasSent)
    {
        if(WhatWasSent=="Food")
        {
            FoodFunction();
            maxSize++;
            score++;
            scoreText.text = score.ToString();
            int temp = PlayerPrefs.GetInt("HighScore");

            if(score>temp)
            {
                PlayerPrefs.SetInt("HighScore", score);
            }
        }
        if(WhatWasSent=="Snake")
        {
            CancelInvoke("TimerInvoke");
            Exit();
        }
    }*/

    
    public void Exit()
    {
        SceneManager.LoadScene(0);
    }
}
