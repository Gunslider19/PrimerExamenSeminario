﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;



public class Snake : MonoBehaviour {

    private Snake next;
    static public Action<String> hit;
    public GameObject snakePrefab;

    public void Setnext(Snake IN)
    {
        next = IN;
    }

    public Snake GetNext()
    {
        return next;
    }
    public void RemoveTail()
    {
        //currentFood = (GameObject)Instantiate(foodPrefab, new Vector2(xPos, yPos), transform.rotation);

        //GameObject clone = (GameObject)Instantiate(snakePrefab);
        Destroy(this.gameObject);
    }
    void OnTriggerEnter(Collider other)
    {
        if(hit!= null)
        {
            hit(other.tag);
        }
        if(other.tag=="Food")
        {
            Destroy(other.gameObject);
        }
    }
}
